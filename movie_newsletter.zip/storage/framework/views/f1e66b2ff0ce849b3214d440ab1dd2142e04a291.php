<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Movie Newsletter Email</title>
</head>
<body>

    <?php if(isset($topRated)): ?>
    <?php $TMDBBASEURL = "https://image.tmdb.org/t/p/w500"; ?>
       <table>
           <thead>
            <th></th>
            <th></th>
           </thead>
           <tbody>
            <?php $__currentLoopData = $topRated->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php $imgUrl = $TMDBBASEURL.$item->poster_path ?>
                        <img src="<?php echo e($imgUrl); ?>" height="400px" width="400px" alt="<?php echo e($item->original_title); ?>'s poster photo">
                    </td>
                    <td style="text-align:top">
                        <div style="padding: 30px">
                            <span style="font-weight: bold; font-size:35px; color:marron"><?php echo e($item->original_title); ?></span> <span>
                                &nbsp;&nbsp;&nbsp;
                                <?php echo e($item->vote_average); ?> / 10 IMDB
                            </span>
                            <br>
                            <span style="font-style: italic">
                                <?php echo e($item->overview); ?>

                            </span>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
       </table>
       
    <?php endif; ?>
    
</body>
</html><?php /**PATH C:\wamp\www\movie_newsletter\resources\views/emails/newsletterEmail.blade.php ENDPATH**/ ?>