<?php $__env->startSection('content'); ?>
<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
<div class="container">
    <div class="row">
        <div class="col-md-7">
            <img width="650px" height="500px" src="<?php echo e(asset('storage/images/movie_photo.jpg')); ?>" alt="Movie photo">
        </div>
        <div class="col-md-5">
            <div class="card">
              

                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <span style="font-weight: bold; color:red"></span><?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <span style="font-weight: bold; color:red"></span><?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>


                    <div>
                        
                        <b>
                            Hi <?php echo e(getFirstNameOfLoggedInUser(Auth::user()->name)); ?> we have sent you a verification email. Please enter your 5-digit code here:
                        </b>


                       
                    </div>
                    <div class="justify-center" style="padding: 120px">
                        
                        <form action="<?php echo e(route('verifyEmail')); ?>" method="POST">
                          
                             <?php echo csrf_field(); ?>
                            
                            <div class="flex justify-center " id="OTPInput">
                            </div>
                            <input hidden id="otp" name="otp" value="<?php echo e(old('otp')); ?>">
                            <br>
                            <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="" role="alert" style="color: red">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <button class="mt-1 button button-danger font-bold text-lg px-2 pt-2 pb-2 rounded bg-black text-white" id="otpSubmit">Confirm Email Addreess</button>
                        </form>
                        <br>
                        Didn't get an email. <a href="<?php echo e(route('resend-verification')); ?>" style="font-weight: bold">Re-send verification</a>

                    </div>

                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('otp_generated_script'); ?>
<script src="<?php echo e(asset('js/otp_generated_script.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\movie_newsletter\resources\views/home.blade.php ENDPATH**/ ?>