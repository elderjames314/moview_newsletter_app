<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MovieLogController extends Controller
{
    //
}
