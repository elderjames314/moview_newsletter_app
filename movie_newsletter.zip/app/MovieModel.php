<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MovieModel extends Model
{
    public $img;
    public $title;
    public $description;
    public $score;
}
